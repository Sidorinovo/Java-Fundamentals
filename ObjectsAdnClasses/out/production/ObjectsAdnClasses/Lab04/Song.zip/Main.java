package Main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        List<Song> songs = new ArrayList<Song>();
        int n = Integer.parseInt(scan.nextLine());
        for (int i = 0; i < n; i++) {
            String[] songDetails = scan.nextLine().split("_");
            songs.add(new Song(songDetails[0], songDetails[1], songDetails[2]));
        }

        String type = scan.nextLine();

        for (Song song : songs) {
            if(song.getTypeList().equals(type)){
                System.out.println(song.getName());
            }
        }

        if(type.equals("all")){
            for (Song song : songs) {
                System.out.println(song.getName());
            }
        }
    }
}
